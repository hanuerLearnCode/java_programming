package tut06.ex03;

public class MovablePoint implements Movable {
    private int x;
    private int y;

    public MovablePoint(int x, int y) {
        this.x = x;
        this.y = y;
    }

    @Override
    public String toString() {
        return "MovablePoint[x=" + this.x + ",y=" + this.y + "]";
    }

    @Override
    public void moveUp() {
        System.out.println("Moving Up!");
        this.y = y + 1;
    }

    @Override
    public void moveDown() {
        System.out.println("Moving Down!");
        this.y = y - 1;
    }

    @Override
    public void moveLeft() {
        System.out.println("Moving Left!");
        this.x = x - 1;
    }

    @Override
    public void moveRight() {
        System.out.println("Moving Right!");
        this.x = x + 1;
    }
}
