package tut06.ex03;

public interface Movable {
    void moveUp();

    void moveDown();

    void moveLeft();

    void moveRight();

}
