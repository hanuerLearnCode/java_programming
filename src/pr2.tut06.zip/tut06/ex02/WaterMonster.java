package tut06.ex02;

public class WaterMonster extends Monster {
    @Override
    public void attack() {
        System.out.println("Water monster attacks with water jets!");
    }
}