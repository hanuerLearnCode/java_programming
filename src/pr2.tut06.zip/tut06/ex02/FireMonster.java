package tut06.ex02;

public class FireMonster extends Monster {

    @Override
    public void attack() {
        System.out.println("Fire monster attacks with fireballs!");
    }
}
