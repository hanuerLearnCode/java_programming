package tut06.ex02;

public class Monster {
    private String name;

    public Monster() {
    }

    public Monster(String name) {
        this.name = name;
    }

    public void attack() {
        System.out.println("This monster attacks with a basic attack!");
    }
}
