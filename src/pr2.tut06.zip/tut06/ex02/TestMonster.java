package tut06.ex02;

public class TestMonster {
    public static void main(String[] args) {
        Monster monster1 = new FireMonster();
        Monster monster2 = new WaterMonster();
        Monster monster3 = new StoneMonster();

        monster1.attack();
        monster2.attack();
        monster3.attack();

        monster2 = new FireMonster();
        monster2.attack();

        Monster monster4 = new Monster(); // Creating an instance of the superclass directly
        System.out.println("A generic monster appears!");
        monster4.attack();
    }
}
