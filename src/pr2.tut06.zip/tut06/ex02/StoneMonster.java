package tut06.ex02;

public class StoneMonster extends Monster {
    @Override
    public void attack() {
        System.out.println("Stone monster attacks with rock throw!");
    }
}
