package tut06.ex01;

public class TestShape {
    public static void main(String[] args) {
        Shape rectangle = new Rectangle(5, 10);
        Shape triangle = new Triangle(4, 6);

        System.out.println("Area of " + rectangle.toString() + " is " + rectangle.getArea());
        System.out.println("Area of " + triangle.toString() + " is " + triangle.getArea());
    }
}
