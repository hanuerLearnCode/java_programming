package tut06.ex01;

public abstract class Shape {

    private String color;

    public abstract double getArea();
    public abstract String toString();
}
